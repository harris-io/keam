# Keam Mark caallcuatro [KEAM 2024]

### Go to https://www.cee.kerala.gov.in/keam2024/ , And click on Candidate response in the left panel
### Press Ctrl + C, and paste it in response.txt.

### Run main.py, and enter your exam date and board exam marks.
